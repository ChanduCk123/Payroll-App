class EmployeesController < ApplicationController
  before_action :authenticate_user!
  before_action :authorize_admin, except: [:show]

  def index
    @employees = Employee.all
  end

  def show
    @employee = Employee.find(params[:id])
  end

  def new
    @employee = Employee.new
  end

  def create
  @employee = Employee.new(employee_params)

  existing_user = User.find_by(email: params[:employee][:email])

  if existing_user
    flash[:alert] = "Error: Email already exists. Use a different email."
    render :new, status: :unprocessable_entity
    return
  end

  # Define new_user before using it
  new_user = User.new(
    name: params[:employee][:name],
    email: params[:employee][:email],
    password: "password123",  # Default password
    role: "employee"
  )

  if new_user.save # Ensure the user is saved first
    @employee.user = new_user  # Associate employee with the saved user
    if @employee.save
      flash[:notice] = "Employee added successfully."
      redirect_to root_path 
    else
      Rails.logger.debug "Employee save failed: #{@employee.errors.full_messages}"
      new_user.destroy  # Rollback user creation if employee save fails
      flash[:alert] = "Error: #{@employee.errors.full_messages.join(", ")}"
      render :new, status: :unprocessable_entity
    end
  else
    Rails.logger.debug "User save failed: #{new_user.errors.full_messages}"
    flash[:alert] = "Error: #{new_user.errors.full_messages.join(", ")}"
    render :new, status: :unprocessable_entity
  end
    # @employee = Employee.new(employee_params)
    # new_user = User.new(
    #   email: params[:employee][:email],
    #   password: "password123",  # Default password
    #   role: "employee"
    # )
  
    # @employee.user = new_user 
    # if @employee.save
    #   flash[:notice] = "Employee added successfully."
    #   redirect_to root_path 
    # else
    #   new_user.destroy
    #   flash[:alert] = "Error: #{@employee.errors.full_messages.join(", ")}"
    #   render :new, status: :unprocessable_entity
    # end
    
  end



  def edit
    @employee = Employee.find(params[:id])
  end

  def update
    @employee = Employee.find(params[:id])
    if @employee.update(employee_params)
      redirect_to root_path, notice: "Employee details updated."
    else
      render :edit
    end
  end

  def destroy
    @employee = Employee.find(params[:id])
    @employee.destroy
    redirect_to root_path, alert: "Employee deleted successfully."
  end

  private

  def employee_params
    params.require(:employee).permit(:name, :email, :address, :salary)
  end

  # def authorize_admin
  #   redirect_to root_path, alert: "Access Denied" unless current_user.admin?
  # end
  def authorize_admin
    Rails.logger.debug "Current user role: #{current_user.role}"
    unless current_user.admin?
      redirect_to root_path, alert: "Access Denied"
    end
  end
end

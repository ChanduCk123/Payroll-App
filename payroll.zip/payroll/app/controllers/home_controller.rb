class HomeController < ApplicationController
  before_action :authenticate_user!

  def index
    if current_user.admin?
      @employees = Employee.all
    else
      @employee = current_user.employee
      # @payslips = current_user.employee.payslips
    end
  end
end

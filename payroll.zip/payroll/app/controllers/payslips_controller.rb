class PayslipsController < ApplicationController
  before_action :set_employee
  before_action :set_payslip, only: [:download_pdf, :send_payslip]

  def index
    if @employee
      @payslips = @employee.payslips.order(year: :desc, month: :desc)
    else
      redirect_to root_path, alert: "No employee record found."
    end
  end

  def create
    payslip = @employee.payslips.create!(
      month: Date.today.strftime("%B"),
      year: Date.today.year,
      salary: @employee.salary,
      generated_at: Time.now
    )
    redirect_to employee_payslips_path(@employee), notice: "Payslip generated successfully!"
  end

  def download_pdf
    pdf = PayslipPdf.new(@payslip)
    send_data pdf.render, filename: "#{@employee.name}_payslip_#{@payslip.month}_#{@payslip.year}.pdf",
              type: "application/pdf", disposition: "inline"
  end

  def send_payslip
    @employee = Employee.find(params[:employee_id])
    @payslip = @employee.payslips.find(params[:id])
    
    PayslipMailer.with(employee: @employee, payslip: @payslip).send_payslip.deliver_now
    redirect_to employee_payslips_path(@employee), notice: "Payslip sent successfully!"
  end


  def destroy
    @employee = Employee.find(params[:employee_id])
    @payslip = @employee.payslips.find(params[:id])
    
    if @payslip.destroy
      redirect_to employee_payslips_path(@employee), notice: "Payslip deleted successfully."
    else
      redirect_to employee_payslips_path(@employee), alert: "Failed to delete payslip."
    end
  end
  
  private

  def set_employee
    @employee = Employee.find(params[:employee_id]) || current_user.employee
    redirect_to root_path, alert: "Employee not found!" if @employee.nil?
  end

  def set_payslip
    @payslip = @employee.payslips.find(params[:id])
  end
end









# class PayslipsController < ApplicationController
#   before_action :authenticate_user!

#   def index
#     if current_user.admin?
#       @payslips = Payslip.all
#     else
#       @payslips = current_user.employee.payslips
#     end
#   end

#   def show
#     @payslip = Payslip.find(params[:id])
#     authorize! @payslip
#   end

#   def create
#     @employee = Employee.find(params[:employee_id])
#     @payslip = @employee.payslips.build(month: Date.today.strftime("%B"), year: Date.today.year, salary: @employee.salary)

#     if @payslip.save
#       generate_pdf(@payslip)
#       PayslipMailer.send_payslip(@payslip).deliver_later
#       redirect_to @payslip, notice: "Payslip generated & emailed."
#     else
#       redirect_to employees_path, alert: "Failed to generate payslip."
#     end
#   end

#   private

#   def generate_pdf(payslip)
#     pdf = Prawn::Document.new
#     pdf.text "Payslip for #{payslip.employee.name}", size: 20, style: :bold
#     pdf.text "Month: #{payslip.month} #{payslip.year}"
#     pdf.text "Salary: #{payslip.salary}"
    
#     pdf_path = Rails.root.join("public", "payslips", "payslip_#{payslip.id}.pdf")
#     pdf.render_file(pdf_path)
#     payslip.update(pdf: pdf_path.to_s)
#   end
# end




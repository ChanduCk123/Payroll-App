// Configure your import map in config/importmap.rb. Read more: https://github.com/rails/importmap-rails

import "@hotwired/turbo-rails";
import "bootstrap"; 

document.addEventListener("DOMContentLoaded", function() {
    setTimeout(function() {
      let alerts = document.querySelectorAll(".alert");
      alerts.forEach(alert => {
        let bsAlert = new bootstrap.Alert(alert);
        bsAlert.close();
      });
    }, 3000); // Auto-hide after 3 seconds
  });
  
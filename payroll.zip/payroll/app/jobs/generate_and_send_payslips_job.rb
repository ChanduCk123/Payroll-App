class GenerateAndSendPayslipsJob < ApplicationJob
  queue_as :default

  def perform
    Employee.find_each do |employee|
      # Generate the payslip
      payslip = employee.payslips.create!(
        month: Date.today.strftime("%B"),
        year: Date.today.year,
        salary: employee.salary,
        generated_at: Time.current
      )

      # Send the payslip via email
      PayslipMailer.with(employee: employee, payslip: payslip).send_payslip.deliver_now
    end
  end
end

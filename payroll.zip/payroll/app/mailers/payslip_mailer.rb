# class PayslipMailer < ApplicationMailer
#     def send_payslip(payslip)
#       @payslip = payslip
#       attachments["Payslip_#{payslip.month}_#{payslip.year}.pdf"] = File.read(payslip.pdf)
#       mail(to: payslip.employee.email, subject: "Your Payslip for #{payslip.month} #{payslip.year}")
#     end
#   end
  
class PayslipMailer < ApplicationMailer
  def send_payslip

    @employee = params[:employee]
    @payslip = params[:payslip]

    attachments["payslip_#{@payslip.month}_#{@payslip.year}.pdf"] = PayslipPdf.new(@payslip).render

    mail(
      to: @employee.email,
      subject: "Your Payslip for #{@payslip.month} #{@payslip.year}"
    )
  end
end

class Employee < ApplicationRecord
  belongs_to :user
  validates :name, :email, :address, :salary, presence: true
  has_many :payslips, dependent: :destroy  #  Ensure Employee has payslips
end

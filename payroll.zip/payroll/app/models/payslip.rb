class Payslip < ApplicationRecord
  belongs_to :employee
end

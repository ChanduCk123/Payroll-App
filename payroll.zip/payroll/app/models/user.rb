class User < ApplicationRecord
  devise :database_authenticatable, :registerable,
         :recoverable, :rememberable, :validatable
  
  has_one :employee, dependent: :destroy

  #enum role: { employee: 0, admin: 1}
  if defined?(role) && self.respond_to?(:role)
    enum role: { employee: 0, admin: 1 }
  end

  def admin?
    role == "admin" || role == 1
  end
  
end

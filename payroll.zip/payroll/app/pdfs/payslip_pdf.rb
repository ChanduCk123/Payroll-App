# require "prawn"

# class PayslipPdf
#   def initialize(payslip)
#     @payslip = payslip
#   end

#   def render
#     Prawn::Document.new do
#       text "Payslip", size: 30, style: :bold, align: :center
#       move_down 20
#       text "Employee Name: #{@payslip.employee.name}", size: 15
#       text "Month: #{@payslip.month} #{@payslip.year}", size: 15
#       text "Salary: $#{@payslip.salary}", size: 15
#       move_down 20
#       text "Generated on: #{@payslip.generated_at.strftime("%d-%m-%Y")}", size: 12, style: :italic
#     end.render
#   end
# end


class PayslipPdf < Prawn::Document
  def initialize(payslip)
    super()
    @payslip = payslip
    @employee = @payslip.employee  # Ensure employee is set

    text "Payslip", size: 30, style: :bold, align: :center
    move_down 20

    if @employee.present?
      text ""
      text "Employee Name: #{@employee.name}", size: 15
      text "Month: #{@payslip.month} #{@payslip.year}", size: 15
      text "Address: #{@employee.address}", size: 15
      text "Salary: $#{@payslip.salary}", size: 15
    else
      text "Employee details not found.", size: 15, color: "FF0000"
    end
  end
end

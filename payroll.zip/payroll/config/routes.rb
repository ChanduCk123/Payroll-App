Rails.application.routes.draw do
  
  # Define your application routes per the DSL in https://guides.rubyonrails.org/routing.html

  # Reveal health status on /up that returns 200 if the app boots with no exceptions, otherwise 500.
  # Can be used by load balancers and uptime monitors to verify that the app is live.
  get "up" => "rails/health#show", as: :rails_health_check

  # Render dynamic PWA files from app/views/pwa/* (remember to link manifest in application.html.erb)
  # get "manifest" => "rails/pwa#manifest", as: :pwa_manifest
  # get "service-worker" => "rails/pwa#service_worker", as: :pwa_service_worker

  # Defines the root path route ("/")
  # root "posts#index"


  devise_for :users

  root to: "home#index"

  # # Employee management routes (only accessible by admins)
  resources :employees do 
    member do
      patch :cancel # This defines `cancel_employee_path`
    end
  end


  # # Payslip routes (employees can see their own, admins can see all)
  resources :employees do
    resources :payslips, only: [:index, :create, :show, :destroy] do
      member do
        get :download_pdf
        post :send_payslip
      end
    end
  end

  # # Sidekiq Web UI (for background job monitoring) - Accessible only by Admins
  require 'sidekiq/web'
   authenticate :user, lambda { |u| u.admin? } do
     mount Sidekiq::Web => "/sidekiq"
   end

 

#   devise_for :users
# authenticated :user do
#   root 'employees#index', as: :authenticated_root
# end
# root 'home#index'

# resources :employees, only: [:index, :show]
# resources :payslips, only: [:index, :show] do
#   get 'download', on: :member
# end

end

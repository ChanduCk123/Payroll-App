# Use this file to define all cron jobs using Whenever.
# Learn more: https://github.com/javan/whenever

set :output, "log/cron.log"

# # Schedule the MonthlyPayslipJob to run at the end of every month
# every '0 0 28-31 * *' do
#   rake "payslip:generate"
# end

every :month, at: 'end of the month at 11:59pm' do
  rake "payslip:generate_and_send"
end

class ChangeRoleTypeInUsers < ActiveRecord::Migration[8.0]
  def change
    remove_column :users, :role, :string # Remove incorrect column type
    add_column :users, :role, :integer, default: 0, null: false # Re-add with correct type
  end
end

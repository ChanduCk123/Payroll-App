require "test_helper"

class PayslipsControllerTest < ActionDispatch::IntegrationTest
  test "should get index" do
    get payslips_index_url
    assert_response :success
  end

  test "should get show" do
    get payslips_show_url
    assert_response :success
  end

  test "should get create" do
    get payslips_create_url
    assert_response :success
  end
end

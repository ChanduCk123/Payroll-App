# Preview all emails at http://localhost:3000/rails/mailers/payslip_mailer
class PayslipMailerPreview < ActionMailer::Preview
end

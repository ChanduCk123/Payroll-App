require "test_helper"

class PayslipTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
